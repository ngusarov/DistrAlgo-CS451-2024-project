#pragma once

#include <unordered_set>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <fstream>
#include <netinet/in.h>
#include <sstream>
#include <set>
#include <tuple>

#include "BEB.hpp"
#include "Messages.hpp"

class LatticeAgreement {
public:
    LatticeAgreement(BEB* beb, int myId, int n, int f, std::ofstream& logFile, unsigned int p, unsigned int ds);

    // Propose a set of integers. Blocks until a decision is reached.
    void propose(int problem_number, const std::vector<int>& proposedValue);

    // Called by BEB when a message is delivered.
    void onMessageReceived(const sockaddr_in& senderAddr, const std::string& msg);

    void flushDecisions();

private:
    // Acceptor and Proposer handlers
    void handleProposal(int senderId,int problem_number, int proposal_number, const std::vector<int>& proposedSet);
    void handleAck(int problem_number,int proposal_number);
    void handleNack(int problem_number,int proposal_number, const std::unordered_set<int>& acceptedSet);

    // Internal methods
    void decide(const std::unordered_set<int>& decidedValue);
    void sendProposal();
    void sendAck(int problem_number, int proposal_number, int proposerId);
    void sendNack(int problem_number, int proposal_number, int proposerId, const std::unordered_set<int>& acceptedSet);

    // Set operations
    void unionSets(std::unordered_set<int>& baseSet, const std::vector<int>& toAdd);
    void unionSets(std::unordered_set<int>& baseSet, const std::unordered_set<int>& toAdd);
    bool isSubset(const std::unordered_set<int>& A, const std::vector<int>& B);

    void flushBufferedLines();

private:
    BEB* beb;
    int myId;
    int n;
    int f;
    unsigned int p;
    unsigned int ds;
    std::ofstream& logFile;

    // Proposer state
    int active_proposal_number;
    int current_problem_number;
    std::mutex mtxProposedValue;
    std::unordered_set<int> proposed_value;
    bool proposing;
    int acksReceived;
    int nacksReceived;

    bool decided;
    std::mutex mtxDecidedSet;
    std::unordered_set<int> decidedSet;

    std::mutex mtx;
    std::condition_variable cv;

    // Acceptor state:
    std::mutex mtxAcceptedValue;
    // std::unordered_set<int> accepted_value; // proposed_value for that proposal_number
    std::unordered_map<int, std::unordered_set<int>> accepted_values;

    std::vector<std::string> decidedLines; // Stores decided lines in memory


    std::mutex ackedProposalsMutex;
    std::set<std::tuple<int, int, int>> ackedProposals;
};