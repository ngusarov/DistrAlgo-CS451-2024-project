#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

void hello(void);

#ifdef __cplusplus
}
#endif
